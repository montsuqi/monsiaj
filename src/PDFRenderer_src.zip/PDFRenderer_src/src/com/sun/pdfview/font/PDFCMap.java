/*
 * $Id: PDFCMap.java,v 1.3 2009/02/12 13:53:54 tomoke Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package com.sun.pdfview.font;

import java.io.IOException;
import java.util.HashMap;
import java.lang.Character;
import java.io.File;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

import com.sun.pdfview.PDFObject;

/**
 * A CMap maps from a character in a composite font to a font/glyph number
 * pair in a CID font.
 *
 * @author  jkaplan
 */
public abstract class PDFCMap {

    /**
     * A cache of known CMaps by name
     */
    private static HashMap<String, PDFCMap> cache;

    /** Creates a new instance of CMap */
    protected PDFCMap() {
    }

    /**
     * Get a CMap, given a PDF object containing one of the following:
     *  a string name of a known CMap
     *  a stream containing a CMap definition
     */
    public static PDFCMap getCMap(PDFObject map) throws IOException {
        if (map.getType() == PDFObject.NAME) {
            return getCMap(map.getStringValue());
        } else if (map.getType() == PDFObject.STREAM) {
            return parseCMap(map);
        } else {
            throw new IOException("CMap type not Name or Stream!");
        }
    }

    /**
     * Get a CMap, given a string name
     */
    public static PDFCMap getCMap(String mapName) throws IOException {
        if (cache == null) {
            populateCache();
        }
        if (!cache.containsKey(mapName)) {
            throw new IOException("Unknown CMap: " + mapName);
        }

        return (PDFCMap) cache.get(mapName);
    }

    /**
     * Populate the cache with well-known types
     */
    protected static void populateCache() {
        cache = new HashMap<String, PDFCMap>();

        // add the Identity-H map
        cache.put("Identity-H", new PDFCMap() {

            public char map(char src) {
                return src;
            }
        });

        // for test
        cache.put("EUC-H", new PDFCMap() {

            public char map(char src) {
                int[][] cidmap = {
                    {0x20, 0x7e, 231},
                    {0x8ea0, 0x8edf, 326},
                    {0xa1a1, 0xa1fe, 633},
                    {0xa2a1, 0xa2ae, 727},
                    {0xa2ba, 0xa2c1, 741},
                    {0xa2ca, 0xa2d0, 749},
                    {0xa2dc, 0xa2ea, 756},
                    {0xa2f2, 0xa2f9, 771},
                    {0xa2fe, 0xa2fe, 779},
                    {0xa3b0, 0xa3b9, 780},
                    {0xa3c1, 0xa3da, 790},
                    {0xa3e1, 0xa3fa, 816},
                    {0xa4a1, 0xa4f3, 842},
                    {0xa5a1, 0xa5f6, 925},
                    {0xa6a1, 0xa6b8, 1011},
                    {0xa6c1, 0xa6d8, 1035},
                    {0xa7a1, 0xa7c1, 1059},
                    {0xa7d1, 0xa7f1, 1092},
                    {0xa8a1, 0xa8a1, 7479},
                    {0xa8a2, 0xa8a2, 7481},
                    {0xa8a3, 0xa8a3, 7491},
                    {0xa8a4, 0xa8a4, 7495},
                    {0xa8a5, 0xa8a5, 7503},
                    {0xa8a6, 0xa8a6, 7499},
                    {0xa8a7, 0xa8a7, 7507},
                    {0xa8a8, 0xa8a8, 7523},
                    {0xa8a9, 0xa8a9, 7515},
                    {0xa8aa, 0xa8aa, 7531},
                    {0xa8ab, 0xa8ab, 7539},
                    {0xa8ac, 0xa8ac, 7480},
                    {0xa8ad, 0xa8ad, 7482},
                    {0xa8ae, 0xa8ae, 7494},
                    {0xa8af, 0xa8af, 7498},
                    {0xa8b0, 0xa8b0, 7506},
                    {0xa8b1, 0xa8b1, 7502},
                    {0xa8b2, 0xa8b2, 7514},
                    {0xa8b3, 0xa8b3, 7530},
                    {0xa8b4, 0xa8b4, 7522},
                    {0xa8b5, 0xa8b5, 7538},
                    {0xa8b6, 0xa8b6, 7554},
                    {0xa8b7, 0xa8b7, 7511},
                    {0xa8b8, 0xa8b8, 7526},
                    {0xa8b9, 0xa8b9, 7519},
                    {0xa8ba, 0xa8ba, 7534},
                    {0xa8bb, 0xa8bb, 7542},
                    {0xa8bc, 0xa8bc, 7508},
                    {0xa8bd, 0xa8bd, 7527},
                    {0xa8be, 0xa8be, 7516},
                    {0xa8bf, 0xa8bf, 7535},
                    {0xa8c0, 0xa8c0, 7545},
                    {0xb0a1, 0xb0fe, 1125},
                    {0xb1a1, 0xb1fe, 1219},
                    {0xb2a1, 0xb2fe, 1313},
                    {0xb3a1, 0xb3fe, 1407},
                    {0xb4a1, 0xb4fe, 1501},
                    {0xb5a1, 0xb5fe, 1595},
                    {0xb6a1, 0xb6fe, 1689},
                    {0xb7a1, 0xb7fe, 1783},
                    {0xb8a1, 0xb8fe, 1877},
                    {0xb9a1, 0xb9fe, 1971},
                    {0xbaa1, 0xbafe, 2065},
                    {0xbba1, 0xbbfe, 2159},
                    {0xbca1, 0xbcfe, 2253},
                    {0xbda1, 0xbdfe, 2347},
                    {0xbea1, 0xbefe, 2441},
                    {0xbfa1, 0xbffe, 2535},
                    {0xc0a1, 0xc0fe, 2629},
                    {0xc1a1, 0xc1fe, 2723},
                    {0xc2a1, 0xc2fe, 2817},
                    {0xc3a1, 0xc3fe, 2911},
                    {0xc4a1, 0xc4fe, 3005},
                    {0xc5a1, 0xc5fe, 3099},
                    {0xc6a1, 0xc6fe, 3193},
                    {0xc7a1, 0xc7fe, 3287},
                    {0xc8a1, 0xc8fe, 3381},
                    {0xc9a1, 0xc9fe, 3475},
                    {0xcaa1, 0xcafe, 3569},
                    {0xcba1, 0xcbfe, 3663},
                    {0xcca1, 0xccfe, 3757},
                    {0xcda1, 0xcdfe, 3851},
                    {0xcea1, 0xcefe, 3945},
                    {0xcfa1, 0xcfd3, 4039},
                    {0xd0a1, 0xd0fe, 4090},
                    {0xd1a1, 0xd1fe, 4184},
                    {0xd2a1, 0xd2fe, 4278},
                    {0xd3a1, 0xd3fe, 4372},
                    {0xd4a1, 0xd4fe, 4466},
                    {0xd5a1, 0xd5fe, 4560},
                    {0xd6a1, 0xd6fe, 4654},
                    {0xd7a1, 0xd7fe, 4748},
                    {0xd8a1, 0xd8fe, 4842},
                    {0xd9a1, 0xd9fe, 4936},
                    {0xdaa1, 0xdafe, 5030},
                    {0xdba1, 0xdbfe, 5124},
                    {0xdca1, 0xdcfe, 5218},
                    {0xdda1, 0xddfe, 5312},
                    {0xdea1, 0xdefe, 5406},
                    {0xdfa1, 0xdffe, 5500},
                    {0xe0a1, 0xe0fe, 5594},
                    {0xe1a1, 0xe1fe, 5688},
                    {0xe2a1, 0xe2fe, 5782},
                    {0xe3a1, 0xe3fe, 5876},
                    {0xe4a1, 0xe4fe, 5970},
                    {0xe5a1, 0xe5fe, 6064},
                    {0xe6a1, 0xe6fe, 6158},
                    {0xe7a1, 0xe7fe, 6252},
                    {0xe8a1, 0xe8fe, 6346},
                    {0xe9a1, 0xe9fe, 6440},
                    {0xeaa1, 0xeafe, 6534},
                    {0xeba1, 0xebfe, 6628},
                    {0xeca1, 0xecfe, 6722},
                    {0xeda1, 0xedfe, 6816},
                    {0xeea1, 0xeefe, 6910},
                    {0xefa1, 0xeffe, 7004},
                    {0xf0a1, 0xf0fe, 7098},
                    {0xf1a1, 0xf1fe, 7192},
                    {0xf2a1, 0xf2fe, 7286},
                    {0xf3a1, 0xf3fe, 7380},
                    {0xf4a1, 0xf4a4, 7474},
                    {0xf4a5, 0xf4a6, 8284},};

                int source = Character.digit(src, 10);
                for (int i = 0; i < cidmap.length; i++) {
                    if (cidmap[i][0] <= src && src <= cidmap[i][1]) {
                        return (char) (cidmap[i][2] + (src - cidmap[i][0]));
                    }
                }
                return 'a';
            }
        });
    }

    /**
     * Parse a CMap from a CMap stream
     */
    protected static PDFCMap parseCMap(PDFObject map) throws IOException {
        /*
        throw new IOException("Parsing CMap Files Unsupported!");
         */
        /*
        File temp = new File("/tmp/hoge.cmap");
        OutputStream out = new BufferedOutputStream(new FileOutputStream(temp));
        out.write(map.getStream());
        out.flush();
        out.close();
        */

        return new PDFCMap() {

            public char map(char src) {
                return (char) (231 + (int) src - 0x20);
            }
        };
    }

    /**
     * Map a given source character to a destination character
     */
    public abstract char map(char src);

    /**
     * Get the font number assoicated with a given source character
     */
    public int getFontID(char src) {
        return 0;
    }
}
