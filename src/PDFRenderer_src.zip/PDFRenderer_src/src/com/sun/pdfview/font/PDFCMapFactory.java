/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sun.pdfview.font;

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *
 * @author mihara
 */
public class PDFCMapFactory extends PDFCMap {

    private String CMapName;

    public String getCMapName() {
        return CMapName;
    }
    private ArrayList<CIDRange> cidRangeList;
    private ArrayList<CodeSpaceRange> codeSpaceRangeList;
    private ArrayList<CIDRange> notDefRangeList;

    public class CIDRange{
        public long start;
        public long end;
        public long cid;

        public CIDRange(long a, long b, long c){
            start = a;
            end = b;
            cid = c;
        }
    }

    public class CodeSpaceRange{
        public String start;
        public String end;

        public CodeSpaceRange(String a, String b){
            start = a;
            end = b;
        }
    }

    public PDFCMapFactory(String input)
    {
        super();
        cidRangeList = new ArrayList<CIDRange>();
        codeSpaceRangeList = new ArrayList<CodeSpaceRange>();
        notDefRangeList = new ArrayList<CIDRange>();
        parseCMap(input);
    }

    public void parseCMap(String input)
    {
        String[] lines;
        Pattern pcmapname = Pattern.compile("^\\s*/CMapName\\s*/([\\w-]+)\\s*def$");
        Pattern pcidchar = Pattern.compile("^\\s*<([a-fA-F\\d]+)>\\s*(\\d+)");
        Pattern pcidrange = Pattern.compile("^\\s*<([a-fA-F\\d]+)>\\s*<([a-fA-F\\d]+)>\\s*(\\d+)");
        Pattern prange = Pattern.compile("^\\s*<([a-fA-F\\d]+)>\\s*<([a-fA-F\\d]+)>");
        Pattern pbegincidchar = Pattern.compile("^(\\d+) begincidchar$");
        Pattern pendcidchar = Pattern.compile("^endcidchar$");
        Pattern pbegincidrange = Pattern.compile("^(\\d+) begincidrange$");
        Pattern pendcidrange = Pattern.compile("^endcidrange$");
        Pattern pbegincodespacerange = Pattern.compile("^(\\d) begincodespacerange$");
        Pattern pendcodespacerange = Pattern.compile("^endcodespacerange$");
        Pattern pbeginnotdefchar = Pattern.compile("^(\\d) beginnotdefchar$");
        Pattern pendnotdefchar = Pattern.compile("^endnotdefchar$");
        Pattern pbeginnotdefrange = Pattern.compile("^(\\d) beginnotdefrange$");
        Pattern pendnotdefrange = Pattern.compile("^endnotdefrange$");

        boolean inCidRange = false;
        boolean inCodeSpaceRange = false;
        boolean inNotDefRange = false;

        lines = input.split("\n");
        for(String line : lines) {
            Matcher mcmapname = pcmapname.matcher(line);
            Matcher mcidchar = pcidchar.matcher(line);
            Matcher mcidrange = pcidrange.matcher(line);
            Matcher mrange = prange.matcher(line);
            Matcher mbegincidchar = pbegincidchar.matcher(line);
            Matcher mendcidchar = pendcidchar.matcher(line);
            Matcher mbegincidrange = pbegincidrange.matcher(line);
            Matcher mendcidrange = pendcidrange.matcher(line);
            Matcher mbegincodespacerange = pbegincodespacerange.matcher(line);
            Matcher mendcodespacerange = pendcodespacerange.matcher(line);
            Matcher mbeginnotdefrange = pbeginnotdefrange.matcher(line);
            Matcher mendnotdefrange = pendnotdefrange.matcher(line);
            Matcher mbeginnotdefchar = pbeginnotdefchar.matcher(line);
            Matcher mendnotdefchar = pendnotdefchar.matcher(line);

            if (mcmapname.find()) {
                this.CMapName = mcmapname.group(1);
            }
            if (mbegincidchar.find() || mbegincidrange.find()) {
                inCidRange = true;
            }
            if (mendcidchar.find() || mendcidrange.find()) {
                inCidRange = false;
            }
            if (mbeginnotdefchar.find() || mbeginnotdefrange.find()) {
                inNotDefRange = true;
            }
            if (mendnotdefchar.find() || mendnotdefrange.find()) {
                inNotDefRange = false;
            }
            if (mbegincodespacerange.find()) {
                inCodeSpaceRange = true;
            }
            if (mendcodespacerange.find()) {
                inCodeSpaceRange = false;
            }


            if (inCidRange) {
                if (mcidchar.find()) {
                    long code = Long.parseLong(mcidchar.group(1),16);
                    long cid = Long.parseLong(mcidchar.group(2),10);
                    cidRangeList.add(new CIDRange(code,code,cid));
                  }
                if (mcidrange.find()) {
                    long start = Long.parseLong(mcidrange.group(1),16);
                    long end = Long.parseLong(mcidrange.group(2),16);
                    long cid = Long.parseLong(mcidrange.group(3),10);
                    cidRangeList.add(new CIDRange(start,end,cid));
                }
            }

            if (inNotDefRange) {
                if (mcidchar.find()) {
                    long start = Integer.parseInt(mcidchar.group(1),16);
                    long cid = Integer.parseInt(mcidchar.group(2),10);
                    notDefRangeList.add(new CIDRange(start,start,cid));
                }
                if (mcidrange.find()) {
                    long start = Long.parseLong(mcidrange.group(1),16);
                    long end = Long.parseLong(mcidrange.group(2), 16);
                    long cid = Long.parseLong(mcidrange.group(3), 10);
                    notDefRangeList.add(new CIDRange(start,end,cid));
                }
            }

            if (inCodeSpaceRange) {
                if (mrange.find()) {
                    codeSpaceRangeList.add(new CodeSpaceRange(mrange.group(1),mrange.group(2)));
                }
            }
        }
    }

    public ArrayList<Character> map(byte[] bytes) {
        ArrayList<Character> list = new ArrayList<Character>();
        int index = 0;
        while(index < bytes.length) {
            boolean inCodeSpace = false;
            long code = 0;
            for (CodeSpaceRange r: codeSpaceRangeList) {
                int size = r.start.length() / 2;
                long start = Integer.parseInt(r.start, 16);
                long end = Integer.parseInt(r.end,16);
                code = 0;
                for (int i = 0; i < size && (index + i) < bytes.length; i++) {
                    code = (code << 8) | bytes[index + i] & 0xff;
                }
                if (start <= code && code <= end) {
                    inCodeSpace = true;
                    index += size;
                    break;
                }
            }
            if (inCodeSpace) {
                long cid = 0;
                for (CIDRange r: notDefRangeList) {
                    if (r.start <= code && code <= r.end) {
                        cid = r.cid + (code - r.start);
                        break;
                    }
                }
                for (CIDRange r: cidRangeList) {
                    if (r.start <= code && code <= r.end) {
                        cid = r.cid + (code - r.start);
                        break;
                    }
                }
                list.add(new Character((char)cid));
            } else {
                index++;
                list.add(new Character((char)0));
            }
        }
        return list;
    }
}
