Directory for 3rd party libraries required by the project. 
Such libraries, if any, will be picked up autmoatically and added to the weekly bundles.