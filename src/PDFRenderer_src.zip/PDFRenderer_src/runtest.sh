#!/bin/sh

java -cp build/classes:./ Test
